var clickActivity = function(){
    var _this = this;

    this.init = function(){
        console.log("INIT FUNCTION INVOKED");

        _this.correctBtn = $('#correct');
        _this.wrongBtn = $('#wrong');
        _this.questionImgContainer = $('.questioinImg');
        _this.feedBackScreen = $('.feedBackScreen');
        _this.closeFeedbackBtn = $('#feedBackCloseBtn');
        _this.feedBackText = $('#feedBackText');
        _this.actvityCloseBtn = $('#actvityCloseBtn');

        _this.clickCount = 0;
        _this.correctClickCount = 0;
        _this.inCorrectClickCount = 0;
        _this.totalClickCount = 6;
        _this.isCorrectlyClicked = false;

        _this.getJsonData();
        _this.addEvents();
    }

    this.getJsonData = function(){
        $.ajax({
            url : "assets/data/data.json",
            type : "GET",
            cache : false,
            success : _this.loadDatasSuccess,
            error : _this.onLoadError
        });
    }

    this.addEvents = function(){
        _this.wrongBtn.off("click").on("click",_this.againstPolicyClicked);
        _this.correctBtn.off("click").on("click",_this.thisIsOkClicked);
        _this.closeFeedbackBtn.off("click").on("click",_this.closeFeedBackScreen);
        _this.actvityCloseBtn.off("click").on("click",_this.closeActvity)
    }
    
    this.loadDatasSuccess = function(jsondatas){
        _this.jsonDatas = jsondatas.data;
        console.log("Json Data Is",_this.jsonDatas);
        for(let i=1; i<=_this.totalClickCount; i++){
            $('#'+i).css('background','none');
        }
        
        _this.loadQuestionImg();
    }

    this.onLoadError = function(){
        console.log("Error on loading json data");
    }

    this.loadQuestionImg = function(){
        _this.questionImgContainer.css({
            "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.activityData[_this.clickCount].questionImage+")",
            "background-size" : "100% 100%"
        });
    }

    this.againstPolicyClicked = function(){
        console.log("Against Policy");

        let currentClick = "Against Policy";
        if(currentClick == _this.jsonDatas.activityData[_this.clickCount].answer){
            console.log("correctly clicked"+_this.jsonDatas.activityData[_this.clickCount].answer);
            _this.correctClickCount++;
            _this.isCorrectlyClicked = true;
        }else{
            console.log("Incorrect click");
            _this.inCorrectClickCount++;
            _this.isCorrectlyClicked = false;
        }

        _this.clickCount++;
        _this.showSignal(_this.clickCount);
        _this.checkAvailablity(_this.clickCount);
    }

    this.thisIsOkClicked = function(){
        console.log("This is ok");
        let currentClick = "This is OK";

        if(currentClick == _this.jsonDatas.activityData[_this.clickCount].answer){
            console.log("correctly clicked"+_this.jsonDatas.activityData[_this.clickCount].answer);
            _this.correctClickCount++;
            _this.isCorrectlyClicked = true;
        }else{
            console.log("Incorrect click");
            _this.inCorrectClickCount++;
            _this.isCorrectlyClicked = false;
        }

        _this.clickCount++;
        _this.showSignal(_this.clickCount);
        _this.checkAvailablity(_this.clickCount);
    }

    this.checkAvailablity = function(){
        if( _this.clickCount == _this.totalClickCount ){
            console.log("Session Closed");
            _this.showFeedBack();
            _this.disableButtons();
        }else{
            setTimeout(_this.loadQuestionImg,100);
        }
    }

    this.showFeedBack = function(){
        console.log("show feedback screen : correct answer count"+  _this.correctClickCount +" wrong answers count : " +_this.inCorrectClickCount);
        _this.feedBackScreen.show();

        _this.feedBackText.text("You have scored " +_this.correctClickCount+ " out of 06 questions correctly!")
    }

    this.disableButtons = function(){
        _this.correctBtn.css('pointer-event','none');
        _this.wrongBtn.css('pointer-event','none');
    }

    this.showSignal = function(count){
        if(_this.isCorrectlyClicked){
            $('#'+count).css({
                "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.signalImage.correct+")",
                "background-size" : "100% 100%"
            });
        }else{
            $('#'+count).css({
                "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.signalImage.incorrect+")",
                "background-size" : "100% 100%"
            });
        }

    }

    this.closeFeedBackScreen = function(){
        _this.feedBackScreen.hide();
        _this.init();
        _this.moveToNext();
    }

    this.closeActvity = function(){
        _this.init();
    }

    this.moveToNext = function(){
        console.log("Move to next activity");
    }
}