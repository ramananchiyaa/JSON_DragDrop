var dragAndDrop = function(){
    var _this = this;

    this.init = function(){
        console.log("INIT FUNCTION INVOKED");

        _this.isCorrectlyDropped = false;
        _this.childCount = 0;
        _this.correctAnswersCount = 0;
        _this.wrongAnswersCount = 0;
        _this.audioObj = $('#audioElem');
        _this.submitBtn = $('#submit');
        _this.ansContainer = $('.correctAnswers');
        _this.feedBackScreen = $('.feedBackScreen');
        _this.activityContainer = $('.dropItemsContainer');
        _this.feedBackImg = $('#feedBackImg');
        _this.closeBtn = $('#closeBtn');
        _this.feedBackText = $('#feedBackText');
        _this.closeActivity = $('#closeActivity');

        _this.getJsonData();
    }

    this.getJsonData = function(){
        $.ajax({
            url : "assets/data/myjsondata.json",
            type : "GET",
            cache : false,
            success : _this.loadDatasSuccess,
            error : _this.onLoadError
        });
    }

    this.loadDatasSuccess = function(jsondatas){
        _this.jsonDatas = jsondatas.data;
        console.log("Json Data Is",_this.jsonDatas);
        _this.setDDItems(_this.jsonDatas);
        _this.playInstructionAudio();
    }

    this.onLoadError = function(){
        console.log("Error on loading json data");
    }

    this.playInstructionAudio = function(){
        _this.audioObj.attr('src',_this.jsonDatas.audioPath+_this.jsonDatas.audio.instructionAudio);
        _this.audioObj[0].play();
    }

    this.setDDItems = function(Data){
        for(let i=0; i<Data.dropData.length; i++){
            $('.textlabel').append("<div>"+Data.dropData[i].text+"</div>");
            $('.placeholdercontainer').append("<div class='dropItemHolder' bayid="+Data.dropData[i].id+" id="+Data.dropData[i].bayId+"></div>");
            $('.dragItemsContainer').append("<div class='dragItemHolder' id="+Data.dragData[i].id+"><div class='dragItems' id="+Data.dropData[i].id+" key="+Data.dragData[i].key+">"+Data.dragData[i].text+"</div></div>")
        }
        $('.dragItems').addClass("draggingElement");
        _this.addEvents();
    }

    this.addEvents = function(){
        $('.dragItems').draggable({
            appendTo: "body",
            containment : $('body'),
            start: function(){
                _this.isCorrectlyDropped = false;
                _this.childCount = 0;
            },
            drag: function(){
                _this.submitBtn.css("pointer-events","none");
                $(this).css('z-index',1);
            },
            stop: function(){
                _this.revert(this);
                $(this).css('z-index',0);
                if(_this.isCorrectlyDropped){
                    console.log('Valid Drop');	
				}else{
                    console.log('Invalid Drop');
                }
            }
        });

        $('.dropItemHolder').droppable({
            drop: function(event,ui){
                _this.isCorrectlyDropped = true;
                _this.curDragElement = $(ui.draggable);
                _this.curDroppedElment = $(this);
                _this.appendElement();
                _this.isFullyDropped();
            }
        });

        _this.submitBtn.off("mousedown").on("mousedown",_this.submitClickEvent);
        _this.submitBtn.off("mouseup").on("mouseup",_this.changeBtnImg);
        _this.submitBtn.off("mouseover").on("mouseover",_this.onTheImg);
        _this.submitBtn.off("mouseout").on("mouseout",_this.changeBtnImg);

        _this.closeBtn.off("mouseover").on("mouseover",_this.changeCloseBtnImg);
        _this.closeBtn.off("mouseout").on("mouseout",_this.changeNormalCloseBtnImg);
        _this.closeBtn.off("mousedown").on("mousedown",_this.clickChangeCloseBtn);
        _this.closeBtn.off("mouseup").on("mouseup",_this.closeFeedBackScreen);
       
        _this.closeActivity.off("mouseover").on("mouseover",_this.activityCloseBtnImg);
        _this.closeActivity.off("mouseout").on("mouseout",_this.activityNormalCloseBtnImg);
        _this.closeActivity.off("mousedown").on("mousedown",_this.activityChangeCloseBtn);
        _this.closeActivity.off("mouseup").on("mouseup",_this.closeFullActivity);
    }

    this.activityCloseBtnImg = function(){
        _this.closeActivity.css("background","url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.closeBtn.onOver+") no-repeat 100% 100%");
    }

    this.activityNormalCloseBtnImg = function(){
        _this.closeActivity.css("background","url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.closeBtn.normal+") no-repeat 100% 100%");
    }

    this.activityChangeCloseBtn = function(){
        _this.closeActivity.css("background","url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.closeBtn.mouseDown+") no-repeat 100% 100%");
    }

    this.closeFullActivity = function(){
        _this.closeActivity.css("background","url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.closeBtn.normal+") no-repeat 100% 100%");
    
        _this.closeThisActvity();
    }

    this.closeThisActvity = function(){
        console.log("Close full activity is called");

        for(let i=0; i<_this.jsonDatas.dragData.length; i++){
            _this.submitBtn.show();
            $('#'+(i+1)).appendTo($('#'+_this.jsonDatas.dragData[i].id));
        }
    }

    this.revert = function(curInvalidElement){
        $(curInvalidElement).css({
            "top" : "0",
            "left" : "0",
            "right" : "0",
            "bottom" : "0"
        });
    }

    this.appendElement = function(){
        _this.curDragId = $(_this.curDragElement).attr('id');
        _this.curDropId = $(_this.curDroppedElment).attr('id');
        $('#'+_this.curDropId).append($('#'+_this.curDragId));

        _this.removeFirstChild(_this.curDropId);
    }

    this.removeFirstChild = function(){
        let childLength = _this.curDroppedElment.children().length;
        
        if(childLength == 2){
            let childern = _this.curDroppedElment.children(),
                removableElement = childern[0],
                removableElementId = $(removableElement).attr('id');

            for(let i=0; i<_this.jsonDatas.dragData.length; i++){
                let temp = _this.jsonDatas.dragData[i].id,
                preParentElem = temp.charAt(8);
                if(preParentElem == removableElementId){
                    $('#'+_this.jsonDatas.dragData[i].id).append($('#'+removableElementId));
                }
            }
        }
    }

    this.isFullyDropped = function(){
        for(let i=0; i<_this.jsonDatas.dropData.length; i++){
            let currentChildLen = $('#'+_this.jsonDatas.dropData[i].bayId).children().length;
            if(currentChildLen == 1){
                _this.childCount++;
            }
        }
        if(_this.childCount == 5){
            _this.submitBtn.css("pointer-events","auto");
        }
    }

    this.submitClickEvent = function(){

        _this.submitBtn.css({
            "background":"url("+_this.jsonDatas.imagePath+_this.jsonDatas.submit.mouseDown+")",
            "background-size" : "100% 100%"
        });
        
        for(let i=0; i<_this.jsonDatas.dropData.length; i++){
            let currentChild = $('#'+_this.jsonDatas.dropData[i].bayId).children().attr('key');

            if(currentChild == _this.jsonDatas.dropData[i].id){
                console.log("correct");
                _this.correctAnswersCount++;
            }else{
                console.log("Incorrect");
                _this.wrongAnswersCount++;
            }

            _this.submitBtn.css("pointer-events","none");
        }

        if(_this.correctAnswersCount == 5){
            _this.audioObj.attr('src',_this.jsonDatas.audioPath+_this.jsonDatas.feedBack.allCorrectAnswers);
            _this.audioObj[0].play();
        }else if(_this.correctAnswersCount == 3 || _this.correctAnswersCount == 4){
            _this.audioObj.attr('src',_this.jsonDatas.audioPath+_this.jsonDatas.feedBack.almostCorrect.audio);
            _this.audioObj[0].play();
            _this.feedBackImg.css({
                "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.almostCorrect.srcImg+")",
                "background-size" : "100% 100%"
            });
            _this.feedBackText.text (_this.jsonDatas.feedBack.almostCorrect.text);

            _this.showAnswer();
        }else if(_this.correctAnswersCount <= 2){
            _this.audioObj.attr('src',_this.jsonDatas.audioPath+_this.jsonDatas.feedBack.itsCorrect.audio);
            _this.audioObj[0].play();
            _this.feedBackImg.css({
                "background" : "url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.itsCorrect.srcImg+")",
                "background-size" : "100% 100%"
            });
            _this.feedBackText.text (_this.jsonDatas.feedBack.itsCorrect.text);

            _this.showAnswer();
        }

        _this.submitBtn.hide();
        _this.correctAnswersCount = 0;
        _this.wrongAnswersCount = 0;
    }

    this.changeBtnImg = function(){
        _this.submitBtn.css({
            "background":"url("+_this.jsonDatas.imagePath+_this.jsonDatas.submit.normal+")",
            "background-size" : "100% 100%"
        });
    }

    this.onTheImg = function(){
        _this.submitBtn.css({
            "background":"url("+_this.jsonDatas.imagePath+_this.jsonDatas.submit.onover+")",
            "background-size" : "100% 100%"
        });
    }

    this.showAnswer = function(){
        _this.feedBackScreen.show();
    }

    this.changeCloseBtnImg = function(){
        _this.closeBtn.css("background","url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.closeBtn.onOver+") no-repeat 100% 100%");
    }

    this.changeNormalCloseBtnImg = function(){
        _this.closeBtn.css("background","url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.closeBtn.normal+") no-repeat 100% 100%");
    }

    this.clickChangeCloseBtn = function(){
        _this.closeBtn.css("background","url("+_this.jsonDatas.imagePath+_this.jsonDatas.feedBack.closeBtn.mouseDown+") no-repeat 100% 100%");
    }

    this.closeFeedBackScreen = function(){      
        _this.feedBackScreen.hide();

        setTimeout(_this.swapToCorrectPlaceholder, 500);
    }

    this.swapToCorrectPlaceholder = function(){
        for(let i=0; i<_this.jsonDatas.dropData.length; i++){
            let key = $('#'+_this.jsonDatas.dropData[i].id).attr('key');

            for(let j=0; j<_this.jsonDatas.dropData.length; j++){

                if(j+1 == key){
                   $('#'+_this.jsonDatas.dropData[i].id).appendTo('#'+_this.jsonDatas.dropData[j].bayId);
                }
            }
        }
    }
}
